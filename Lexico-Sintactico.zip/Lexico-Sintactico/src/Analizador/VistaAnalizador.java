package Analizador;

import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.nio.file.Files;
import java.util.logging.*;
import java_cup.runtime.Symbol;
import javax.swing.*;
import javax.swing.border.*;

/**
 *
 * @author danie
 */


public class VistaAnalizador extends JFrame implements ActionListener {
    
    public JPanel panel;
    public JLabel lblEntrada, lblLexico, lblSintactico;
    public JButton btnLexico, btnSintactico, btnLimpiarLexico, btnLimpiarSintactico, btnAbrir, btnGuardar;
    public JTextArea txtInput, txtLexico, txtSintactico;
    public JScrollPane scrollEntrada, scrollLexico, scrollSintactico;
    
    JFileChooser escoger = new JFileChooser();
    File archivo;
    FileInputStream input;
    FileOutputStream output;
    
    
    public VistaAnalizador(){

        this.setTitle("Analizador Lexico-Sintactico");
        this.setSize(1090, 700);
        this.setResizable(false);
        this.setLocationRelativeTo(null);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        panel = new JPanel();
        panel.setBorder(new EmptyBorder(5,5,5,5));
        panel.setLayout(null);
        panel.setBackground(new Color(0, 191, 255));
        setContentPane(panel);
        
        lblEntrada = new JLabel("Escribe tu código o");
        lblEntrada.setForeground(Color.BLACK);
        lblEntrada.setFont(new Font("Berlin Sans FB", 0, 20));
        lblEntrada.setBounds(10, 10, 170, 30);
        panel.add(lblEntrada);
        
        lblLexico = new JLabel("Analizador Léxico");
        lblLexico.setForeground(Color.BLACK);
        lblLexico.setFont(new Font("Berlin Sans FB", 0, 20));
        lblLexico.setBounds(590, 10, 400, 30);
        panel.add(lblLexico);
        
        lblSintactico = new JLabel("Analizador Sintáctico");
        lblSintactico.setForeground(Color.BLACK);
        lblSintactico.setFont(new Font("Berlin Sans FB", 0, 20));
        lblSintactico.setBounds(360, 410, 400, 30);
        panel.add(lblSintactico);
        
        btnAbrir = new JButton("Abre tu Archivo C");
        btnAbrir.setFont(new Font("Berlin Sans FB", 0, 15));
        btnAbrir.setForeground(Color.WHITE);
        btnAbrir.setBackground(new Color(112, 128, 144));
        btnAbrir.setBounds(190, 10, 160, 30);
        btnAbrir.addActionListener(this);
        panel.add(btnAbrir);
        
        btnLexico = new JButton("Analizar Léxico");
        btnLexico.setFont(new Font("Berlin Sans FB", 0, 15));
        btnLexico.setForeground(Color.WHITE);
        btnLexico.setBackground(new Color(112, 128, 144));
        btnLexico.setBounds(910, 50, 160, 30);
        btnLexico.addActionListener(this);
        panel.add(btnLexico);
        
        btnGuardar = new JButton("Guardar Cambios");
        btnGuardar.setFont(new Font("Berlin Sans FB", 0, 15));
        btnGuardar.setForeground(Color.WHITE);
        btnGuardar.setBackground(new Color(112, 128, 144));
        btnGuardar.setBounds(910, 90, 160, 30);
        btnGuardar.addActionListener(this);
        panel.add(btnGuardar);
        
        btnSintactico = new JButton("Analizar Sintáctico");
        btnSintactico.setFont(new Font("Berlin Sans FB", 0, 15));
        btnSintactico.setForeground(Color.WHITE);
        btnSintactico.setBackground(new Color(112, 128, 144));
        btnSintactico.setBounds(910, 450, 160, 30);
        btnSintactico.addActionListener(this);
        panel.add(btnSintactico);
        
        btnLimpiarLexico = new JButton("Limpiar");
        btnLimpiarLexico.setFont(new Font("Berlin Sans FB", 0, 15));
        btnLimpiarLexico.setForeground(Color.WHITE);
        btnLimpiarLexico.setBackground(new Color(112, 128, 144));
        btnLimpiarLexico.setBounds(910, 130, 160, 30);
        btnLimpiarLexico.addActionListener(this);
        panel.add(btnLimpiarLexico);
        
        btnLimpiarSintactico = new JButton("Limpiar");
        btnLimpiarSintactico.setFont(new Font("Berlin Sans FB", 0, 15));
        btnLimpiarSintactico.setForeground(Color.WHITE);
        btnLimpiarSintactico.setBackground(new Color(112, 128, 144));
        btnLimpiarSintactico.setBounds(910, 490, 160, 30);
        btnLimpiarSintactico.addActionListener(this);
        panel.add(btnLimpiarSintactico);
        
        txtInput = new JTextArea();
        txtInput.setFont(new Font("Berlin Sans FB", 0, 15));
        txtInput.setForeground(Color.BLACK);
        txtInput.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
        
        txtLexico = new JTextArea();
        txtLexico.setFont(new Font("Berlin Sans FB", 0, 15));
        txtLexico.setForeground(Color.BLACK);
        txtLexico.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
        txtLexico.setEditable(false);
        
        txtSintactico = new JTextArea();
        txtSintactico.setFont(new Font("Berlin Sans FB", 0, 15));
        txtSintactico.setForeground(Color.BLACK);
        txtSintactico.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
        txtSintactico.setEditable(false);
        
        scrollEntrada = new JScrollPane(txtInput, JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
        scrollEntrada.setBounds(10, 50, 430, 350);
        panel.add(scrollEntrada);
        
        scrollLexico = new JScrollPane(txtLexico, JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
        scrollLexico.setBounds(460, 50, 430, 350);
        panel.add(scrollLexico);
        
        scrollSintactico = new JScrollPane(txtSintactico, JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
        scrollSintactico.setBounds(10, 450, 880, 200);
        panel.add(scrollSintactico);
        
    } 
    
    public String GuardarArchivo(File archivo, String documento){
        String mensaje = null;
        try{
            output = new FileOutputStream(archivo);
            byte[] bytxt=documento.getBytes();
            output.write(bytxt);
            mensaje="Archivo Guardado";
        } catch (Exception e){          
        }
          return mensaje;
    }
    
    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource()==btnLexico){
            archivo = new File("archivo.txt");
            PrintWriter escribir;
            try {
                escribir = new PrintWriter(archivo);
                escribir.print(txtInput.getText());
                escribir.close();
            } catch (FileNotFoundException ex) {
                Logger.getLogger(VistaAnalizador.class.getName()).log(Level.SEVERE, null, ex);
            }
            
            try {
                Reader lector = new BufferedReader(new FileReader("archivo.txt"));
                Lexico lexer = new Lexico(lector);
                String resultado = "";
                while(true){
                    Tokens tokens = lexer.yylex();
                    if(tokens == null){
                        txtLexico.setText(resultado);
                        return;
                    }
                    switch(tokens){
                        case ERROR:
                            resultado += "Símbolo no definido\n";
                            break;
                        case Comillas: case Byte: case Int: case Char: case Long: case Float: 
                        case Double: case Cadena: case If: case Else: case Do: case While: 
                        case For: case Igual: case Suma: case Resta: case Multiplicacion: case Division: 
                        case Dos_Puntos: case Punto: case Operador_logico: case Operador_relacional: 
                        case Operador_atribucion: case Operador_incremento: case Operador_booleano: 
                        case Parentesis_cerrado: case Parentesis_abierto: case Llave_abierta: 
                        case Llave_cerrada: case Corchete_abierto: case Corchete_cerrado: case Main: 
                        case Identificador: case Numero:
                            resultado += lexer.lexeme + ": Es un " + tokens + "\n";
                            break;
                        default:
                            resultado += "Token: " + tokens + "\n";
                            break;
                    }
                }
            } catch (FileNotFoundException ex) {
                Logger.getLogger(VistaAnalizador.class.getName()).log(Level.SEVERE, null, ex);
            } catch (IOException ex) {
                Logger.getLogger(VistaAnalizador.class.getName()).log(Level.SEVERE, null, ex);
            }
        } else if (e.getSource()==btnLimpiarLexico){
            txtLexico.setText("");
        } else if (e.getSource()==btnSintactico){
            String ST = txtInput.getText();
            Sintaxis s = new Sintaxis(new Analizador.LexicoCup(new StringReader(ST)));
            
            try{
                s.parse();
                txtSintactico.setText("Analisis realizado correctamente");
            } catch (Exception ex) {
                Symbol sym = s.getS();
                txtSintactico.setText("Error de sintaxis. Linea: "+(sym.right+1)+" Columna: "+(sym.left+1)+", Texto: \""+sym.value+"\"");
            }
        } else if (e.getSource()==btnLimpiarSintactico){
            txtSintactico.setText("");
        } else if (e.getSource()==btnGuardar){
            if(escoger.showDialog(null, "Guardar")==JFileChooser.APPROVE_OPTION){
                archivo= escoger.getSelectedFile();
                if(archivo.getName().endsWith("c")){
                    String Documento = txtInput.getText();
                    String mensaje= GuardarArchivo(archivo, Documento);
                    if(mensaje!=null){
                        JOptionPane.showMessageDialog(null, mensaje);
                    }else{
                        JOptionPane.showMessageDialog(null, "Archivo no compatible");
                    }
                }else{
                    JOptionPane.showMessageDialog(null, "Guardar documento de texto");
                }
            }   
        } else if (e.getSource()==btnAbrir){
            int cont = 1;
            escoger.showOpenDialog(null);
            File arc = new File(escoger.getSelectedFile().getAbsolutePath());
            try {
                String ST = new String(Files.readAllBytes(arc.toPath()));
                txtInput.setText(ST);
            }catch (FileNotFoundException ex){
                Logger.getLogger(VistaAnalizador.class.getName()).log(Level.SEVERE,null,ex);
            }catch (IOException ex){
            Logger.getLogger(VistaAnalizador.class.getName()).log(Level.SEVERE,null,ex);
            }
        }
    }
    
    public static void main(String[] args){
        new VistaAnalizador().setVisible(true);
    }
}